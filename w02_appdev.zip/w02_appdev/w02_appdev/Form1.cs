﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace w02_appdev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string chosenWord;
        public char[] answer = new char[5];
        public string[] words = new string[5];
        public bool errorCheck;

        private void btn_play_Click(object sender, EventArgs e)
        {
            errorCheck = false;;
            foreach (string word in words)
            {
                if (word.Length != 5)
                {
                    errorCheck = true;
                    MessageBox.Show("Invalid Input: Please input words with 5 letters");
                }
            }

            for (int i = 0; i < words.Length; i++)
            {
                words[i] = words[i].ToUpper();
            }
            for (int i = 0; i < words.Length; i++)
            {
                for (int j = 0; j < words.Length; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    else
                    {
                        if (words[i] == words[j])
                        {
                            errorCheck = true;
                            MessageBox.Show("Invalid Input: Please input unique words");
                        }
                    }
                }
            }

            string validLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < 5; i++)
            {
                int check = 0;
                foreach (char c in words[i])
                {
                    if (validLetters.Contains(c))
                    {
                        check++;
                    }
                }
                if (check != 5)
                {
                    errorCheck = true;
                    MessageBox.Show("Invalid Input: Please input words with no digits");
                }
            }

            if (errorCheck == false)
            {
                Form2 game = new Form2(words);
                game.ShowDialog();
                this.Close();
            }
        }

        private void tb_word1_TextChanged(object sender, EventArgs e)
        {
            words[0] = tb_word1.Text.ToUpper();
        }

        private void tb_word2_TextChanged(object sender, EventArgs e)
        {
            words[1] = tb_word2.Text.ToUpper();
        }

        private void tb_word3_TextChanged(object sender, EventArgs e)
        {
            words[2] = tb_word3.Text.ToUpper();
        }

        private void tb_word4_TextChanged(object sender, EventArgs e)
        {
            words[3] = tb_word4.Text.ToUpper();
        }

        private void tb_word5_TextChanged(object sender, EventArgs e)
        {
            words[4] = tb_word5.Text.ToUpper();
        }
    }
}
