﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace w02_appdev
{
    public partial class Form2 : Form
    {
        public string chosenWord;
        public char[] answer = new char[5];
        public string[] words = new string[5];
        public int trueGuess = 0;

        public Form2(string[] words)
        {
            InitializeComponent();
            Random randomizer = new Random();
            int indexChosenWord = randomizer.Next(0, 5);
            chosenWord = words[indexChosenWord];

            int count = 0;
            foreach (char c in chosenWord)
            {
                answer[count] = c;
                count++;
            }
        }

        private void btn_letter_Click(object sender, EventArgs e)
        {
            int trueGuess = 0;
            Button letters = sender as Button;
            string words = letters.Text.ToString();
            char answer = Convert.ToChar(words);
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == answer)
                {
                    trueGuess = i;
                    if (trueGuess == 0)
                    {
                        lb_letter_1.Text = answer.ToString();
                    }
                    if (trueGuess == 1)
                    {
                        lb_letter_2.Text = answer.ToString();
                    }
                    if (trueGuess == 2)
                    {
                        lb_letter_3.Text = answer.ToString();
                    }
                    if (trueGuess == 3)
                    {
                        lb_letter_4.Text = answer.ToString();
                    }
                    if (trueGuess == 4)
                    {
                        lb_letter_5.Text = answer.ToString();
                    }
                    if (lb_letter_1.Text != "_" && lb_letter_2.Text != "_" && lb_letter_3.Text != "_" && lb_letter_4.Text != "_" && lb_letter_5.Text != "_")
                    {
                        MessageBox.Show("Game Over, You Win!");
                    }
                }
            }
        }
    }
}
