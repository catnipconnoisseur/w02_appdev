﻿namespace w02_appdev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_input = new System.Windows.Forms.Panel();
            this.btn_play = new System.Windows.Forms.Button();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.lb_word5 = new System.Windows.Forms.Label();
            this.lb_word4 = new System.Windows.Forms.Label();
            this.lb_word3 = new System.Windows.Forms.Label();
            this.lb_word2 = new System.Windows.Forms.Label();
            this.lb_word1 = new System.Windows.Forms.Label();
            this.pnl_input.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_input
            // 
            this.pnl_input.Controls.Add(this.btn_play);
            this.pnl_input.Controls.Add(this.tb_word5);
            this.pnl_input.Controls.Add(this.tb_word4);
            this.pnl_input.Controls.Add(this.tb_word3);
            this.pnl_input.Controls.Add(this.tb_word2);
            this.pnl_input.Controls.Add(this.tb_word1);
            this.pnl_input.Controls.Add(this.lb_word5);
            this.pnl_input.Controls.Add(this.lb_word4);
            this.pnl_input.Controls.Add(this.lb_word3);
            this.pnl_input.Controls.Add(this.lb_word2);
            this.pnl_input.Controls.Add(this.lb_word1);
            this.pnl_input.Location = new System.Drawing.Point(584, 226);
            this.pnl_input.Name = "pnl_input";
            this.pnl_input.Size = new System.Drawing.Size(285, 325);
            this.pnl_input.TabIndex = 0;
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(96, 256);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(90, 44);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "Play";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(134, 207);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(127, 26);
            this.tb_word5.TabIndex = 9;
            this.tb_word5.TextChanged += new System.EventHandler(this.tb_word5_TextChanged);
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(134, 162);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(127, 26);
            this.tb_word4.TabIndex = 8;
            this.tb_word4.TextChanged += new System.EventHandler(this.tb_word4_TextChanged);
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(134, 118);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(127, 26);
            this.tb_word3.TabIndex = 7;
            this.tb_word3.TextChanged += new System.EventHandler(this.tb_word3_TextChanged);
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(134, 76);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(127, 26);
            this.tb_word2.TabIndex = 6;
            this.tb_word2.TextChanged += new System.EventHandler(this.tb_word2_TextChanged);
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(134, 33);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(127, 26);
            this.tb_word1.TabIndex = 5;
            this.tb_word1.TextChanged += new System.EventHandler(this.tb_word1_TextChanged);
            // 
            // lb_word5
            // 
            this.lb_word5.AutoSize = true;
            this.lb_word5.Location = new System.Drawing.Point(36, 210);
            this.lb_word5.Name = "lb_word5";
            this.lb_word5.Size = new System.Drawing.Size(60, 20);
            this.lb_word5.TabIndex = 4;
            this.lb_word5.Text = "Word 5";
            // 
            // lb_word4
            // 
            this.lb_word4.AutoSize = true;
            this.lb_word4.Location = new System.Drawing.Point(36, 165);
            this.lb_word4.Name = "lb_word4";
            this.lb_word4.Size = new System.Drawing.Size(60, 20);
            this.lb_word4.TabIndex = 3;
            this.lb_word4.Text = "Word 4";
            // 
            // lb_word3
            // 
            this.lb_word3.AutoSize = true;
            this.lb_word3.Location = new System.Drawing.Point(36, 121);
            this.lb_word3.Name = "lb_word3";
            this.lb_word3.Size = new System.Drawing.Size(60, 20);
            this.lb_word3.TabIndex = 2;
            this.lb_word3.Text = "Word 3";
            // 
            // lb_word2
            // 
            this.lb_word2.AutoSize = true;
            this.lb_word2.Location = new System.Drawing.Point(36, 79);
            this.lb_word2.Name = "lb_word2";
            this.lb_word2.Size = new System.Drawing.Size(60, 20);
            this.lb_word2.TabIndex = 1;
            this.lb_word2.Text = "Word 2";
            // 
            // lb_word1
            // 
            this.lb_word1.AutoSize = true;
            this.lb_word1.Location = new System.Drawing.Point(36, 39);
            this.lb_word1.Name = "lb_word1";
            this.lb_word1.Size = new System.Drawing.Size(60, 20);
            this.lb_word1.TabIndex = 0;
            this.lb_word1.Text = "Word 1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1557, 889);
            this.Controls.Add(this.pnl_input);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_input.ResumeLayout(false);
            this.pnl_input.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_input;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.TextBox tb_word5;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.Label lb_word5;
        private System.Windows.Forms.Label lb_word4;
        private System.Windows.Forms.Label lb_word3;
        private System.Windows.Forms.Label lb_word2;
        private System.Windows.Forms.Label lb_word1;
    }
}

